# Dati di esempio

Metti qui solo dati **anonimizzati**: niente nomi, codici fiscali, IBAN, indirizzi, email o dati di
clienti reali. Sostituiscili con valori inventati ma realistici.
