# Prima di caricare il progetto su Beyond

- [ ] README (Idea Card) compilato in tutte le sezioni, problema espresso in numeri
- [ ] `beyond-progetto.json` completo e uguale al README
- [ ] Il prototipo si avvia seguendo solo il README
- [ ] Tre casi di prova provati, con input e risultato atteso
- [ ] Dati di esempio anonimizzati in `esempi/` (nessuno se il semaforo è rosso)
- [ ] Nessuna password, chiave API o token nel codice o nella cronologia (usa `.env`)
- [ ] Nessun dato di clienti, contratti o dato personale nel repository
- [ ] Repository privato, IT (`Coesaenergy`, `maero-coesa`) aggiunto come collaboratore
- [ ] Tutto committato e pushato su GitHub
- [ ] Zip creato con lo script della skill e caricato su Beyond → "Carica il tuo progetto"
