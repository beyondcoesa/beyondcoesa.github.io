Il codice del prototipo va in questa cartella (script, flussi, fogli, prompt).
