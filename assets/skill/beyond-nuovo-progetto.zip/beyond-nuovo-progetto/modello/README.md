# <Titolo del progetto>

> Prototipo per **Beyond**, la piattaforma dell'Ufficio Innovazione di Coesa Energy.
> Questo README è l'**Idea Card**: gli stessi contenuti sono in `beyond-progetto.json`, che Beyond
> usa per compilare il modulo "Carica il tuo progetto".

| | |
|---|---|
| **Reparto** | … |
| **Autore** | Nome Cognome |
| **AI Champion** | Matteo Stoppa / Lorenzo Maero / Federico d'Agostino / nessuno |
| **Semaforo dati** | verde / giallo / rosso |
| **Stato** | Prototipo |

## 1. Il problema, in numeri
Che cosa non funziona oggi? Quante ore a settimana, quante persone, quanti errori.

## 2. Il risultato atteso
Che cosa cambia quando lo strumento funziona, e come lo misuriamo.

## 3. Chi lo usa e quanto spesso
Utenti, frequenza d'uso, beneficio stimato, eventuale scadenza.

## 4. Come si usa
- **Scopo**: …
- **Input**: …
- **Passi**:
  1. …
- **Esempio di risultato**: …
- **Limiti noti**: …

## 5. Come avviarlo
Passi esatti per farlo partire su un altro PC (programmi, versioni, file da preparare).
Le impostazioni personali vanno in `.env` (vedi `.env.example`), **mai** nel codice.

## 6. Casi di prova
Vedi [`CASI-DI-PROVA.md`](CASI-DI-PROVA.md).

## 7. Dati e sistemi
Sistemi coinvolti, dati usati (descritti a parole), semaforo. In `esempi/` solo dati anonimizzati.

## 8. Chi l'ha provato
Chi l'ha usato, per quanto tempo, con che risultato.
