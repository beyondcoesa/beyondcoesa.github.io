﻿<#
  Beyond · controllo del progetto e preparazione dello zip per "Carica il tuo progetto".

  Uso (dalla cartella del progetto):
    powershell -NoProfile -ExecutionPolicy Bypass -File controlla-progetto.ps1 -SoloControlli
        controlli prima di un push: chiavi, file vietati, formato di beyond-progetto.json
    powershell -NoProfile -ExecutionPolicy Bypass -File controlla-progetto.ps1
        consegna: campi obbligatori completi, tutto su GitHub, crea consegna\<repository>.zip

  Esce con codice 1 se trova errori. Non stampa mai il contenuto delle righe sospette.
#>
param(
  [switch]$SoloControlli,
  [string]$Cartella = (Get-Location).Path
)

$ErrorActionPreference = "Stop"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

$errori = New-Object System.Collections.Generic.List[string]
$avvisi = New-Object System.Collections.Generic.List[string]
function Err($m) { $errori.Add($m) }
function Avv($m) { $avvisi.Add($m) }

function GitOut {
  param([Parameter(ValueFromRemainingArguments = $true)] $argomenti)
  $out = & git -C $script:Radice @argomenti 2>$null
  return $out
}

# ---------------------------------------------------------------- repository
$Radice = (& git -C $Cartella rev-parse --show-toplevel 2>$null)
if (-not $Radice) {
  Write-Host "ERRORE: $Cartella non è un repository git. Apri la cartella del progetto (fase 3 della skill)." -ForegroundColor Red
  exit 1
}
$Radice = $Radice.Trim()
$NomeRepo = Split-Path $Radice -Leaf
Write-Host "Progetto: $NomeRepo ($Radice)"

# ---------------------------------------------------------------- beyond-progetto.json
$MAX_TESTO = 2000
$AMMESSI = @{
  funzione       = @("Direzione", "Commerciale Fotovoltaico", "Operation Fotovoltaico", "Commerciale RE-ETS", "Commerciale PA",
                     "Amministrazione", "Operation RE-ETS / PA", "Innovation", "Strategy", "Marketing & Communication", "HR", "Finance")
  champion       = @("Matteo Stoppa", "Lorenzo Maero", "Federico d'Agostino")
  frequenza      = @("Più volte al giorno", "Ogni giorno", "Ogni settimana", "Ogni mese", "Occasionalmente")
  beneficio_tipo = @("Tempo liberato", "Margine", "Qualità", "Rischio evitato")
  urgenza        = @("Nessuna scadenza", "Scadenza")
  mvp_tipo       = @("Prompt", "Foglio di calcolo", "Flusso o automazione", "Bozza di schermata", "Prototipo o app", "Altro")
  sistemi        = @("Odoo", "Excel e file condivisi", "Email", "Documenti e PDF", "Portali esterni", "Nessuno", "Altro")
  semaforo       = @("verde", "giallo", "rosso")
}
$OBBLIGATORI = @("titolo", "funzione", "nome", "cognome", "email", "problema", "risultato", "misura", "utenti",
  "frequenza", "beneficio_tipo", "beneficio", "mvp_tipo", "scopo", "input", "passi", "esempio", "limiti",
  "provato_da", "caso1_input", "caso1_atteso", "caso2_input", "caso2_atteso", "caso3_input", "caso3_atteso",
  "sistemi", "dati_descr", "semaforo")
$TESTI = @("titolo", "champion", "nome", "cognome", "email", "problema", "risultato", "misura", "utenti", "beneficio",
  "urgenza_data", "urgenza_motivo", "scopo", "input", "passi", "esempio", "limiti", "provato_da",
  "caso1_input", "caso1_atteso", "caso2_input", "caso2_atteso", "caso3_input", "caso3_atteso", "dati_descr", "note")

$fileJson = Join-Path $Radice "beyond-progetto.json"
$progetto = $null
$campi = $null
if (-not (Test-Path $fileJson)) {
  Err "Manca beyond-progetto.json nella radice del progetto."
} else {
  try {
    $progetto = [System.IO.File]::ReadAllText($fileJson, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
  } catch {
    Err "beyond-progetto.json non è un JSON valido: $($_.Exception.Message)"
  }
}

function Valore($nome) {
  if ($null -eq $campi) { return $null }
  $p = $campi.PSObject.Properties[$nome]
  if ($null -eq $p) { return $null }
  if ($p.Value -is [array]) { return , $p.Value }   # la virgola evita che PowerShell "srotoli" l'elenco
  return $p.Value
}
function Pieno($v) {
  if ($null -eq $v) { return $false }
  if ($v -is [array]) { return $v.Count -gt 0 }
  return ([string]$v).Trim().Length -gt 0
}

if ($progetto) {
  if ($progetto.formato -ne "beyond-progetto/1") { Err "beyond-progetto.json: 'formato' deve essere ""beyond-progetto/1""." }
  $campi = $progetto.campi
  if ($null -eq $campi) { Err "beyond-progetto.json: manca l'oggetto 'campi'." }

  $repo = [string]$progetto.repository
  if (-not $repo) {
    if ($SoloControlli) { Avv "repository non ancora indicato in beyond-progetto.json." } else { Err "Manca 'repository' (link GitHub) in beyond-progetto.json." }
  } elseif ($repo -notmatch '^https://github\.com/[A-Za-z0-9-]+/[A-Za-z0-9._-]+/?$') {
    Err "'repository' deve essere un link https://github.com/<utente>/<repository>."
  }

  if ($campi) {
    $noti = @($AMMESSI.Keys) + $TESTI + @("ore_settimana", "persone")
    foreach ($p in $campi.PSObject.Properties) {
      if ($noti -notcontains $p.Name) { Avv "Campo sconosciuto in beyond-progetto.json (Beyond lo ignora): $($p.Name)" }
    }
    foreach ($k in $TESTI) {
      $v = Valore $k
      if ($null -ne $v -and -not ($v -is [string])) { Err "Il campo '$k' deve essere un testo." ; continue }
      $max = if ($k -eq "titolo") { 90 } else { $MAX_TESTO }
      if ($v -and $v.Length -gt $max) { Err "Il campo '$k' supera $max caratteri ($($v.Length))." }
    }
    foreach ($k in $AMMESSI.Keys) {
      $v = Valore $k
      if (-not (Pieno $v)) { continue }
      $multi = @("beneficio_tipo", "sistemi") -contains $k
      if ($multi -and -not ($v -is [array])) { Err "Il campo '$k' deve essere un elenco, es. [""$($AMMESSI[$k][0])""]."; continue }
      foreach ($x in @($v)) {
        if ($AMMESSI[$k] -cnotcontains $x) { Err "Valore non ammesso in '$k': ""$x"". Ammessi: $($AMMESSI[$k] -join ', ')." }
      }
    }
    $sis = Valore "sistemi"
    if ($sis -is [array] -and $sis -contains "Nessuno" -and $sis.Count -gt 1) { Err "'sistemi': ""Nessuno"" va da solo." }
    foreach ($k in @("ore_settimana", "persone")) {
      $v = Valore $k
      if ($null -ne $v -and "$v" -ne "" -and -not ($v -is [int] -or $v -is [long] -or $v -is [double] -or $v -is [decimal])) { Err "'$k' deve essere un numero (o null)." }
      elseif ($null -ne $v -and "$v" -ne "" -and [double]$v -lt 0) { Err "'$k' non può essere negativo." }
    }
    $em = [string](Valore "email")
    if ($em -and $em -notmatch '^[^@\s]+@coesaenergy\.(com|it)$') { Err "'email' deve essere l'indirizzo aziendale @coesaenergy.com o @coesaenergy.it." }
    if ((Valore "urgenza") -eq "Scadenza") {
      $d = [string](Valore "urgenza_data")
      if ($d -notmatch '^\d{4}-\d{2}-\d{2}$') { Err "Con urgenza ""Scadenza"" serve 'urgenza_data' nel formato AAAA-MM-GG." }
      if (-not (Pieno (Valore "urgenza_motivo"))) { Err "Con urgenza ""Scadenza"" serve 'urgenza_motivo'." }
    }
    $mancanti = @($OBBLIGATORI | Where-Object { -not (Pieno (Valore $_)) })
    if ($mancanti.Count) {
      $msg = "Campi obbligatori ancora vuoti: " + ($mancanti -join ", ")
      if ($SoloControlli) { Avv $msg } else { Err $msg }
    }
    $prob = [string](Valore "problema")
    if ($prob -and $prob -notmatch '\d') { Avv "'problema' non contiene numeri: Beyond chiede il problema espresso in numeri." }
  }
}

# ---------------------------------------------------------------- file nel repository
$tracciati = @(GitOut ls-files)
$vietati = $tracciati | Where-Object {
  ($_ -match '(^|/)\.env($|\.)' -and $_ -notmatch '(^|/)\.env\.example$') -or
  $_ -match '\.(pem|key|p12|pfx)$' -or $_ -match '(^|/)(credentials|secrets|service-account)[^/]*\.json$'
}
foreach ($f in $vietati) { Err "File che non deve stare su GitHub: $f (toglilo con 'git rm --cached' e, se contiene chiavi, revocale)." }

$semaforo = [string](Valore "semaforo")
$datiEsempio = @($tracciati | Where-Object { $_ -like "esempi/*" -and $_ -ne "esempi/README.md" })
if ($semaforo -eq "rosso" -and $datiEsempio.Count) {
  Err "Semaforo rosso: in esempi/ non ci devono essere dati ($($datiEsempio -join ', '))."
}
$documenti = @($tracciati | Where-Object { $_ -match '\.(pdf|docx?|xlsx?|csv)$' -and $_ -notlike "esempi/*" })
foreach ($f in $documenti) { Avv "Documento o dato fuori da esempi/: $f. Controlla che non contenga dati veri." }

# ---------------------------------------------------------------- chiavi e segreti (file attuali e cronologia)
$PATTERN = @(
  '-----BEGIN [A-Z ]*PRIVATE KEY',
  'sk-[A-Za-z0-9_-]{20,}', 'sk-ant-[A-Za-z0-9_-]{20,}',
  'AKIA[0-9A-Z]{16}', 'AIza[0-9A-Za-z_-]{35}',
  'ghp_[A-Za-z0-9]{30,}', ('github' + '_pat_[A-Za-z0-9_]{20,}'), 'xox[abprs]-[A-Za-z0-9-]{10,}',
  'sb_secret_[A-Za-z0-9_-]{10,}', 'service_role',
  'eyJhbGciOi[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}'
)
$unico = '(' + ($PATTERN -join ')|(') + ')'
# Assegnazioni tipo  password = "..."  : possono essere falsi allarmi, quindi solo avviso
$generico = '(?i)(password|passwd|pwd|secret|token|api[_-]?key)["'' ]*[:=] *["''][^\s"'']{8,}["'']'
$dubbi = New-Object System.Collections.Generic.HashSet[string]
$sospetti = New-Object System.Collections.Generic.HashSet[string]
foreach ($f in $tracciati) {
  if ($f -eq ".env.example") { continue }
  $percorso = Join-Path $Radice $f
  if (-not (Test-Path $percorso -PathType Leaf)) { continue }
  if ((Get-Item $percorso).Length -gt 2MB) { continue }
  try { $testo = [System.IO.File]::ReadAllText($percorso) } catch { continue }
  if ($testo.IndexOf([char]0) -ge 0) { continue }   # file binario
  $righe = $testo -split "`n"
  for ($i = 0; $i -lt $righe.Length; $i++) {
    if ($righe[$i] -match $unico) { [void]$sospetti.Add("${f}:$($i + 1)") }
    elseif ($righe[$i] -match $generico) { [void]$dubbi.Add("${f}:$($i + 1)") }
  }
}
foreach ($s in $dubbi) { Avv "Controlla ${s}: sembra una password o un token scritto nel codice (se è vero, spostalo in .env)." }
foreach ($s in $sospetti) { Err "Possibile chiave o password in $s (non la stampo). Spostala in .env e, se è vera, revocala." }

# API di Claude e di altri modelli AI: riservate all'IT, il prototipo del collega non le usa
$apiAI = '(?i)(api\.anthropic\.com|anthropic_api_key|@anthropic-ai/sdk|^\s*(from|import)\s+anthropic\b|api\.openai\.com|openai_api_key|^\s*(from|import)\s+openai\b|require\(["'']openai)'
$usaApi = New-Object System.Collections.Generic.HashSet[string]
foreach ($f in $tracciati) {
  if ($f -match '\.md$') { continue }
  $percorso = Join-Path $Radice $f
  if (-not (Test-Path $percorso -PathType Leaf) -or (Get-Item $percorso).Length -gt 2MB) { continue }
  try { $righe = [System.IO.File]::ReadAllLines($percorso) } catch { continue }
  for ($i = 0; $i -lt $righe.Length; $i++) { if ($righe[$i] -match $apiAI) { [void]$usaApi.Add("${f}:$($i + 1)") } }
}
foreach ($s in $usaApi) { Err "Il prototipo usa l'API di Claude o di un altro modello AI ($s): le API sono riservate all'IT. Usa Claude dall'account aziendale e documenta il prompt." }

$storia = (& git -C $Radice log --all -p --no-color --format="@@commit %h" 2>$null) -join "`n"
if ($storia) {
  $commitSospetti = New-Object System.Collections.Generic.HashSet[string]
  $commit = ""
  foreach ($r in ($storia -split "`n")) {
    if ($r.StartsWith("@@commit ")) { $commit = $r.Substring(9); continue }
    if ($r.StartsWith("+") -and -not $r.StartsWith("+++") -and $r -match $unico) { [void]$commitSospetti.Add($commit) }
  }
  if ($commitSospetti.Count -and -not $sospetti.Count) {
    Err ("Possibile chiave nella cronologia di git (commit " + (($commitSospetti | Select-Object -First 5) -join ", ") +
      "): anche se l'hai tolta dal file resta su GitHub. Revoca la chiave e avvisa l'Ufficio Innovazione.")
  }
}

# ---------------------------------------------------------------- GitHub (solo per la consegna)
if (-not $SoloControlli) {
  $stato = @(GitOut status --porcelain)
  if ($stato.Count) { Err "Ci sono modifiche non salvate in git ($($stato.Count) file): fai commit e push." }
  $origine = [string](GitOut config --get remote.origin.url)
  if (-not $origine) { Err "Il repository non è collegato a GitHub (manca 'origin')." }
  else {
    $normale = ($origine.Trim() -replace '\.git$', '' -replace '/$', '')
    if ($progetto -and $progetto.repository -and $normale -ne ([string]$progetto.repository -replace '/$', '')) {
      Err "'repository' in beyond-progetto.json ($($progetto.repository)) non coincide con origin ($normale)."
    }
    & git -C $Radice fetch -q origin 2>$null
    $davanti = [string](GitOut rev-list --count "@{u}..HEAD")
    if ($LASTEXITCODE -ne 0 -or $davanti -eq "") { Err "Il ramo attuale non è su GitHub: fai 'git push -u origin HEAD'." }
    elseif ([int]$davanti -gt 0) { Err "$davanti commit non ancora su GitHub: fai push." }
  }
  if (Get-Command gh -ErrorAction SilentlyContinue) {
    $vis = (& gh repo view --json visibility --jq .visibility 2>$null)
    if ($vis -and $vis.Trim() -ne "PRIVATE") { Err "Il repository su GitHub non è privato ($vis): rendilo privato (gh repo edit --visibility private --accept-visibility-change-consequences)." }
  } else {
    Avv "GitHub CLI non trovato: non ho potuto verificare che il repository sia privato."
  }
}

# ---------------------------------------------------------------- esito
Write-Host ""
foreach ($a in $avvisi) { Write-Host "AVVISO: $a" -ForegroundColor Yellow }
foreach ($e in $errori) { Write-Host "ERRORE: $e" -ForegroundColor Red }
if ($errori.Count) {
  Write-Host ""
  Write-Host "Controllo NON superato: $($errori.Count) errori." -ForegroundColor Red
  exit 1
}
if ($SoloControlli) {
  Write-Host "Controlli superati: puoi fare push." -ForegroundColor Green
  exit 0
}

$cartellaConsegna = Join-Path $Radice "consegna"
New-Item -ItemType Directory -Force -Path $cartellaConsegna | Out-Null
$zip = Join-Path $cartellaConsegna "$NomeRepo.zip"
if (Test-Path $zip) { Remove-Item $zip -Force }
& git -C $Radice archive --format=zip --prefix="$NomeRepo/" -o $zip HEAD
if ($LASTEXITCODE -ne 0 -or -not (Test-Path $zip)) { Write-Host "ERRORE: non sono riuscito a creare lo zip." -ForegroundColor Red; exit 1 }
$mb = [math]::Round((Get-Item $zip).Length / 1MB, 1)
Write-Host "Zip pronto: $zip ($mb MB)" -ForegroundColor Green
if ($mb -gt 15) { Write-Host "AVVISO: supera 15 MB. Beyond compila comunque il modulo, ma non allega lo zip: l'IT userà il link GitHub." -ForegroundColor Yellow }
Write-Host "Ultimo passo: Beyond -> Carica il tuo progetto -> trascina lo zip nel riquadro 'Carica lo zip del progetto'."
exit 0
