# PC e GitHub

Comandi per Windows (PowerShell). Esegui tu i comandi; chiedi al collega solo i passaggi nel browser.

## 1. Git e GitHub CLI
Controlla:
```
git --version
gh --version
```
Se manca qualcosa, installalo con winget (chiede conferma a Windows, il collega deve dire sì):
```
winget install --id Git.Git -e --source winget --accept-package-agreements --accept-source-agreements
winget install --id GitHub.cli -e --source winget --accept-package-agreements --accept-source-agreements
```
Dopo l'installazione il terminale può non trovarli subito: usa i percorsi completi
`"C:\Program Files\Git\cmd\git.exe"` e `"C:\Program Files\GitHub CLI\gh.exe"`, oppure chiedi al
collega di chiudere e riaprire Claude Code. Se winget non c'è o fallisce, manda il collega su
https://git-scm.com/download/win e https://cli.github.com e fai installare con le opzioni predefinite.

## 2. Account GitHub (lo fa il collega)
Chiedi se ha già un account GitHub **con l'email aziendale**.
- **No** → guidalo:
  1. https://github.com/signup con l'**email aziendale**, username semplice (es. `nome-cognome-coesa`);
  2. conferma l'email con il codice ricevuto;
  3. *Settings → Password and authentication → Enable two-factor authentication* (app di autenticazione
     sul telefono). Fai salvare i codici di recupero in un posto sicuro.
- **Sì, ma con un'email personale** → aggiunga l'email aziendale (*Settings → Emails*) oppure crei un
  account nuovo. Il repository del progetto deve stare su un account legato all'email aziendale.

## 3. Accesso di GitHub CLI
```
gh auth status
```
Se non è collegato, il login richiede il browser e un codice: chiedi al collega di scrivere **lui**
nel prompt di Claude Code (il `!` lo esegue nel suo terminale):
```
! gh auth login --hostname github.com --git-protocol https --web
```
Gli comparirà un codice di 8 caratteri: lo copia, preme Invio, il browser si apre, entra in GitHub,
incolla il codice e autorizza. Poi:
```
gh auth setup-git
gh auth status
gh api user --jq .login
```
Annota lo username (`login`): serve per il link del repository.

## 4. Nome ed email nei commit
```
git config --global user.name "Nome Cognome"
git config --global user.email "nome@coesaenergy.com"
git config --global init.defaultBranch main
```
(Usa nome ed email veri del collega, presi dall'intervista.)

## 5. Repository
Dalla cartella del progetto:
```
git init
git add -A
git commit -m "Primo commit: Idea Card e struttura del progetto"
gh repo create <nome-repository> --private --source . --remote origin --push --description "Prototipo per Beyond: <titolo>"
gh repo view --json visibility,url --jq ".visibility + ' ' + .url"
```
Deve risultare `PRIVATE`. Metti l'`url` in `beyond-progetto.json` → `repository`, poi commit e push.

Aggiungi l'IT come collaboratore (ricevono un invito da accettare):
```
gh api -X PUT repos/{owner}/<nome-repository>/collaborators/Coesaenergy -f permission=push
gh api -X PUT repos/{owner}/<nome-repository>/collaborators/maero-coesa -f permission=push
```
(`{owner}` viene sostituito da gh con l'account del collega, se lanci il comando dentro la cartella
del repository.) Verifica con `gh api repos/{owner}/<nome-repository>/invitations --jq ".[].invitee.login"`.

## Problemi frequenti
| Messaggio | Cosa fare |
|---|---|
| `gh: command not found` / `git` non riconosciuto | Percorsi completi (sezione 1) o riavvio di Claude Code |
| `HTTP 401` / `authentication required` | Rifare il login (sezione 3) |
| `name already exists on this account` | Il repository c'è già: usa quello (`git remote add origin …`) o scegli un altro nome |
| `Permission denied` su push | `gh auth setup-git`, poi riprova |
| Push rifiutato perché il remoto ha commit nuovi | `git pull --rebase`, risolvi, poi push (mai `--force`) |
| Il collega non riceve l'email di verifica | Controllare spam; in alternativa farsi aiutare dall'IT |
