# Campi di Beyond e file `beyond-progetto.json`

Il modulo *Carica il tuo progetto* di Beyond legge `beyond-progetto.json` dallo zip e compila i
campi. I nomi delle chiavi e i valori ammessi devono essere **identici** a quelli qui sotto: un valore
diverso viene scartato e il collega dovrà sceglierlo a mano.

## Formato
```json
{
  "formato": "beyond-progetto/1",
  "repository": "https://github.com/<username>/proto-<reparto>-<nome>",
  "campi": {
    "titolo": "",
    "funzione": "",
    "champion": "",
    "nome": "",
    "cognome": "",
    "email": "",
    "problema": "",
    "ore_settimana": null,
    "persone": null,
    "risultato": "",
    "misura": "",
    "utenti": "",
    "frequenza": "",
    "beneficio_tipo": [],
    "beneficio": "",
    "urgenza": "Nessuna scadenza",
    "urgenza_data": "",
    "urgenza_motivo": "",
    "mvp_tipo": "",
    "scopo": "",
    "input": "",
    "passi": "",
    "esempio": "",
    "limiti": "",
    "provato_da": "",
    "caso1_input": "", "caso1_atteso": "",
    "caso2_input": "", "caso2_atteso": "",
    "caso3_input": "", "caso3_atteso": "",
    "sistemi": [],
    "dati_descr": "",
    "semaforo": "",
    "note": ""
  }
}
```
- File in **UTF-8**, nella radice del repository, versionato con git (finisce nello zip).
- Testi: massimo **2000 caratteri** per campo (`titolo` 90). A capo con `\n`.
- `ore_settimana` (anche decimali, es. 7.5) e `persone` (intero) sono **numeri** o `null`.
- `urgenza_data` nel formato `AAAA-MM-GG`, solo se `urgenza` è `"Scadenza"`.
- Il link MVP del modulo è `repository`: deve essere `https://github.com/...`.
- I file di `esempi/` (tranne `README.md`) vengono allegati come **dati di esempio**. Con semaforo
  rosso `esempi/` deve contenere solo `README.md`.
- La conferma sull'anonimizzazione dei dati **non** sta nel file: la dà il collega su Beyond.

## Valori ammessi
| Campo | Valori (scrivili esattamente così) |
|---|---|
| `funzione` (il reparto) | `Direzione`, `Commerciale Fotovoltaico`, `Operation Fotovoltaico`, `Commerciale RE-ETS`, `Commerciale PA`, `Amministrazione`, `Operation RE-ETS / PA`, `Innovation`, `Strategy`, `Marketing & Communication`, `HR`, `Finance` |
| `champion` (facoltativo) | `Matteo Stoppa`, `Lorenzo Maero`, `Federico d'Agostino`, oppure `""` se nessuno |
| `frequenza` | `Più volte al giorno`, `Ogni giorno`, `Ogni settimana`, `Ogni mese`, `Occasionalmente` |
| `beneficio_tipo` (uno o più) | `Tempo liberato`, `Margine`, `Qualità`, `Rischio evitato` |
| `urgenza` | `Nessuna scadenza`, `Scadenza` |
| `mvp_tipo` | `Prompt`, `Foglio di calcolo`, `Flusso o automazione`, `Bozza di schermata`, `Prototipo o app`, `Altro` |
| `sistemi` (uno o più) | `Odoo`, `Excel e file condivisi`, `Email`, `Documenti e PDF`, `Portali esterni`, `Nessuno`, `Altro` (`Nessuno` da solo) |
| `semaforo` | `verde`, `giallo`, `rosso` |
| `email` | indirizzo aziendale `@coesaenergy.com` o `@coesaenergy.it` |

## Nome del repository
`proto-<reparto>-<nome>`, tutto minuscolo, parole separate da `-`, senza accenti, al massimo ~40
caratteri. Sigle per `<reparto>`:

| Reparto | Sigla |
|---|---|
| Direzione | `direzione` |
| Commerciale Fotovoltaico | `commerciale-fv` |
| Operation Fotovoltaico | `operation-fv` |
| Commerciale RE-ETS | `commerciale-reets` |
| Commerciale PA | `commerciale-pa` |
| Amministrazione | `amministrazione` |
| Operation RE-ETS / PA | `operation-reets-pa` |
| Innovation | `innovation` |
| Strategy | `strategy` |
| Marketing & Communication | `marketing` |
| HR | `hr` |
| Finance | `finance` |

Esempi: `proto-operation-fv-verbali-vocali`, `proto-amministrazione-solleciti-fornitori`.

## Intervista
Domande da fare (con parole tue), e campo che compilano. Gli **obbligatori** sono in grassetto.

**Scelta multipla quando puoi.** Per i campi con valori ammessi (reparto, AI Champion, frequenza,
tipo di beneficio, urgenza, tipo di MVP, sistemi, semaforo) usa lo strumento delle domande a scelta
multipla di Claude Code (`AskUserQuestion`), con le opzioni prese dalla tabella "Valori ammessi".
Ogni domanda ha al massimo 4 opzioni: se i valori sono di più (per esempio i 12 reparti) chiedi
prima l'area e poi il reparto, oppure mostra i più probabili e lascia scrivere la risposta.
Anche per i testi proponi 2-4 bozze tra cui scegliere (titolo, risultato, misura, casi di prova…)
invece di una domanda aperta. Il collega può sempre rispondere a parole sue.

Le domande della tabella sono una traccia: falle brevi e con parole tue, una alla volta. Usa quello
che il collega ha già detto per scrivere le bozze. Non rifare domande a cui ha già risposto.

Esempio di domanda ben fatta:
> Ok, il problema è chiaro. Come capiremo che funziona?
> 1. Ore spese sui solleciti: da 6 a 1 a settimana (consigliata)
> 2. Solleciti dimenticati: da ~5 al mese a 0
> 3. Tempo per rispondere a un fornitore: da 2 giorni a 1
>
> (oppure scrivi la tua)

Per i 12 reparti, chiedi prima l'area con 4 opzioni:
- Commerciale (Fotovoltaico, RE-ETS, PA);
- Operation (Fotovoltaico, RE-ETS / PA);
- Amministrazione e Finance (Amministrazione, Finance, HR);
- Direzione e staff (Direzione, Innovation, Strategy, Marketing & Communication).

Poi chiedi il reparto dentro l'area scelta.

**Fase 2 — prima di costruire**
| Domanda | Campo |
|---|---|
| Come ti chiami? Qual è la tua email aziendale? | **`nome`**, **`cognome`**, **`email`** |
| In quale reparto lavori? (scelta multipla) | **`funzione`** |
| Quale AI Champion ti segue: Matteo Stoppa, Lorenzo Maero, Federico d'Agostino o nessuno? (scelta multipla) | `champion` |
| Dammi un nome breve per il progetto (proponine 2-3 tu). | **`titolo`** |
| Che cosa non funziona oggi? Quante ore a settimana ci perdete, quante persone, quanti errori o ritardi? (serve almeno un numero) | **`problema`**, `ore_settimana`, `persone` |
| Che cosa deve cambiare quando lo strumento funziona? | **`risultato`** |
| Come capiremo che funziona? (un numero prima/dopo) | **`misura`** |
| Chi lo userà, quante persone e con che ruolo? Quanto spesso? | **`utenti`**, **`frequenza`** |
| Che tipo di beneficio porta e quanto vale, anche a stima? | **`beneficio_tipo`**, **`beneficio`** |
| C'è una scadenza o un evento che lo rende urgente? Quale e perché? | `urgenza`, `urgenza_data`, `urgenza_motivo` |
| Con quali sistemi lavora (Odoo, Excel, email, PDF, portali come GSE)? | **`sistemi`** |
| Quali dati usa? (descrivili a parole, senza incollarli) | **`dati_descr`** |
| Semaforo: spiega i tre livelli e proponi tu quello corretto | **`semaforo`** |

**Fase 3-4 — mentre si costruisce**
| Domanda | Campo |
|---|---|
| Che forma ha il prototipo? (lo decidete insieme) | **`mvp_tipo`** |

**Fase 5 — alla consegna** (proponi tu le bozze dal codice e dalle prove)
| Domanda | Campo |
|---|---|
| A che cosa serve, in una frase? | **`scopo`** |
| Che cosa serve per farlo funzionare? (file, dati, accessi) | **`input`** |
| Quali sono i passi per usarlo? (elenco numerato) | **`passi`** |
| Che cosa si ottiene quando funziona bene? | **`esempio`** |
| Quando non funziona o va usato con cautela? | **`limiti`** |
| Chi l'ha provato, per quanto tempo, con che risultato? | **`provato_da`** |
| Tre casi di prova: situazione e input → risultato atteso (il terzo difficile o al limite) | **`caso1_input`** … **`caso3_atteso`** |
| Qualcosa da aggiungere per l'Ufficio Innovazione? | `note` |

Scrivi nel README (Idea Card) e in `CASI-DI-PROVA.md` gli stessi contenuti del JSON: il JSON serve a
Beyond, il README alle persone.
