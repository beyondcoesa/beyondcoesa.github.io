# Regole di Beyond per i prototipi

Riassunto delle regole del Programma AI-first di Coesa Energy che valgono per chi prepara un
prototipo. Il processo completo è su Beyond → *Come funziona*.

## Principi
1. **Output first**: si parte dal risultato atteso, misurabile, non dalla tecnologia.
2. **Chi propone, prototipa**: la funzione porta un MVP funzionante (anche rudimentale) e le
   istruzioni per usarlo. Un'idea senza prototipo resta un'idea.
3. **Un solo backlog**: tutte le richieste competono per le stesse risorse con le stesse regole.
4. **Non tutto è AI**: prima di costruire si verifica se basta un cambio di processo o
   un'automazione tradizionale.
5. **Gate verificabili**: si passa alla fase successiva quando i criteri di uscita sono soddisfatti.
6. **L'autonomia si guadagna**: si sperimenta in un perimetro protetto; dati reali e produzione
   arrivano dopo i controlli dell'Ufficio Innovazione.
7. **Ogni ciclo insegna**: esiti, tempi e benefici finiscono in una memoria condivisa.

## Le fasi che toccano al collega
- **Fase 0, Segnalazione** → Idea Card. Criterio di uscita: problema espresso **in numeri** e
  risultato atteso chiaro.
- **Fase 1, MVP e istruzioni** (fino a 15 giorni lavorativi) → pacchetto di richiesta. Criterio di
  uscita: checklist del pacchetto completa (Idea Card, MVP, istruzioni, tre casi di prova, semaforo,
  dati di esempio anonimizzati).

Dopo l'invio: triage dell'Ufficio Innovazione entro 5 giorni lavorativi, con uno di cinque esiti,
sempre motivato (Accettata, Da integrare, Risolvibile senza AI, Già coperta, Non ora). Una richiesta
incompleta torna indietro **una sola volta**: meglio consegnarla completa.

## Semaforo sicurezza dati
| Livello | Dati | Dove si prototipa |
|---|---|---|
| **Verde** | Pubblici o interni non sensibili, uso personale | Strumenti approvati, in autonomia |
| **Giallo** | Dati aziendali interni: offerte, costi, fornitori | Solo negli ambienti indicati dall'Ufficio Innovazione, nessuna condivisione esterna |
| **Rosso** | Dati personali, clienti, contratti, credenziali, scrittura sul gestionale (Odoo) | Solo l'Ufficio Innovazione, in ambiente protetto |

Conseguenze pratiche:
- **Verde**: si può prototipare in autonomia; in `esempi/` dati di esempio realistici.
- **Giallo**: nel prototipo e in `esempi/` solo dati **anonimizzati** o inventati (niente nomi veri di
  fornitori o clienti, importi alterati). Non inviare dati aziendali a servizi esterni non approvati
  (siti di conversione, AI pubbliche non aziendali, ecc.).
- **Rosso**: nessun dato vero, né nel codice né in `esempi/` né in chat. Il prototipo lavora con dati
  inventati; la consegna avvisa l'IT che preparerà i dati in ambiente protetto. Il prototipo **non
  scrive** su Odoo: al massimo legge, e solo in un ambiente di prova indicato dall'IT.
- Nel dubbio tra due livelli, scegli il **più alto**.

## AI Champion
Gli AI Champion sono **Matteo Stoppa**, **Lorenzo Maero** e **Federico d'Agostino**: primo filtro
interno, aiutano a preparare il pacchetto di richiesta e tengono il filo con l'Ufficio Innovazione.
Sono il riferimento per dubbi su regole, dati e semaforo.

## Codice e repository
- Un prototipo = un repository **privato** `proto-<reparto>-<nome>` nell'account GitHub personale
  del collega (registrato con l'email aziendale, verifica in due passaggi attiva). L'IT
  (`Coesaenergy`, `maero-coesa`) è collaboratore.
- **Mai** password, token, chiavi API, certificati nel codice o nella cronologia di git: vanno in
  `.env`, che è escluso da git. Se una chiave finisce per sbaglio in un commit, va **revocata** e
  sostituita (cancellarla dal file non basta: resta nella cronologia).
- **Mai** nel repository: dati personali, dati di clienti, contratti, documenti riservati (il
  documento di governance AI è riservato e non va né caricato né citato).
- Il README è l'Idea Card e deve permettere a un'altra persona di avviare il prototipo da sola.
- Tre **casi di prova** con input e risultato atteso: diventano i criteri di accettazione quando
  l'IT costruisce la versione di produzione. Il terzo è un caso difficile o al limite.

## Strumenti
- **Le API di Claude sono a disposizione solo del comparto IT**, non dei singoli colleghi. Il
  collega usa Claude con il proprio account aziendale (Claude Code, claude.ai) e non crea chiavi API
  di Claude, Anthropic o altri modelli AI. Se il prototipo avrà bisogno dell'API, il collega lo
  dimostra con prompt documentati e prove manuali; il collegamento all'API lo fa l'IT in produzione.
- Si usano gli strumenti approvati dall'azienda (Claude con l'account aziendale, Microsoft 365 /
  Google Workspace aziendali, Odoo). Per altri servizi esterni chiedi all'Ufficio Innovazione prima
  di inviarci dati gialli.
- Preferisci soluzioni semplici che l'IT possa leggere e mantenere: HTML/JavaScript, Python, fogli
  di calcolo, prompt documentati.
